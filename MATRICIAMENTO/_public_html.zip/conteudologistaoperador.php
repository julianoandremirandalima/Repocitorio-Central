<div class="row gy-4">

          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="100">
            <div class="box">
            <a href="venda_p1.php">
              <div class="icon"><i class="bi bi-cash-coin"></i></div>
              <h4 class="title">EFETUAR VENDAS</h4>
              <p class="description">PARA VENDAS COM O CARTÃO SINDSERVA.</p>
              </a>
            </div>
          </div>

          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="200">
            <div class="box">
            <a href="relatorio_vendas_operador.php">
              <div class="icon"><i class="bi bi-pencil-square"></i></div>
              <h4 class="title">RELATÓRIO DE VENDAS</h4>
              <p class="description">RESUMO.</p>
              </a>
            </div>
          </div>

        

          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="200">
            <div class="box">
            <a href="help-suporte.php">
              <div class="icon"><i class="bi bi-question-diamond"></i></div>
              <h4 class="title">CENTRAL SINDSERVA - DÚVIDAS</h4>
              <p class="description">QUALQUER DÚVIDA, ENTRE EM CONTATO AQUI!</p>
              </a>
            </div>
          </div>

         

        </div>