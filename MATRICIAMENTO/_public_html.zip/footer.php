﻿<footer id="footer" style="background-color: #fff;">
    <div class="container">
      <div class="copyright" style="color:#099" >
        &copy; Copyright <strong>Sistema Sindserva</strong>. Versão 1.0.2
      </div>
     
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>
<script src="assets/js/jquery-3.5.1.js"></script>
<script src="assets/js/jquery.dataTables.min.js"></script>
<script src="assets/js/dataTables.bootstrap5.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.11/jquery.mask.min.js"></script>
<script type="text/javascript">
    $("#celular, #telefone_u, #celular_u, #wattsap, #wattsap_u").mask("(00) 00000-0000");
	$("#telefone").mask("(00) 0000-0000");
	$("#cpf, #cpf_u").mask("000.000.000-00");
	$("#cep, #cep_u").mask("00000-000");

  $(".telefone").mask("(00) 0000-0000");
	$(".cpf").mask("000.000.000-00");
	$(".cep").mask("00000-000");
  $(".cnpj").mask("000.000.000/0000-00");

	$(".mascaracep").mask("00000-000");
  $(".mascaratelefonefixo").mask("(00) 0000-0000");
  $(".mascaracelular").mask("(00) 00000-0000");
  $(".moeda").mask("9999.00");
    </script>

 
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
	<script>
        $(document).ready(function() {
            $('.servidorx').select2();
        });
    </script>
