
          <li><a class="nav-link scrollto" href="principal.php">PRINCIPAL</a></li>
          
          
          <li><a class="nav-link scrollto " href="relatorio_compras.php">MEU SINDCARD</a></li>
         
          
         
           
          
        