<?php
		//tem que ser a quantidade exata dos campos postados do form senão dá erro no javascritp e não inputa no banco!
		$nome=$_POST['nome'];
		$data = $_POST['data'];
		$parentesco = $_POST['parentesco'];
		
		
?>