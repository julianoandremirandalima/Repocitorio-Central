
          <li><a class="nav-link scrollto" href="principal.php">PRINCIPAL</a></li>
          
          <li><a class="nav-link scrollto" href="cadServidor.php">SERVIDORES</a></li>
		 <li><a class="nav-link scrollto" href="cadloja.php">EMPRESAS</a></li>
          <li><a class="nav-link scrollto" href="caduser.php">USUÁRIOS</a></li>
        
         
          
         
           
          
           
           
         