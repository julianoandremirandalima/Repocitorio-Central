<?php

$user = 'u817888175_sistema';
$password = 'Fracos13';
$con = new PDO( 'mysql:host=localhost;dbname=u817888175_sistema', $user, $password );
$con->exec("SET CHARACTER SET utf8");


?>