
          <li><a class="nav-link scrollto" href="principal.php">PRINCIPAL</a></li>
          
          
          <li><a class="nav-link scrollto " href="principal.php">SINDCARD</a></li>
         
          
          
           
          
        