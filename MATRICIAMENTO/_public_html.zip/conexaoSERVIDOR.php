<?php

$user = 'sindserv_sindserva';
$password = '.9o22]uvFn8a';
$con = new PDO( 'mysql:host=localhost;dbname=sindserv_sistema', $user, $password );
$con->exec("SET CHARACTER SET utf8");


?>