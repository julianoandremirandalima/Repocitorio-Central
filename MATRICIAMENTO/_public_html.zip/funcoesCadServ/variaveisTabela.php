<?php
		
		$nome=$_POST['nome'];
		$matricula=$_POST['matricula'];
		$local=$_POST['local'];
		$setor=$_POST['setor'];
		$data = $_POST['data'];
		$estadocivil = $_POST['estadocivil'];
		$sexo = $_POST['sexo'];
		$escolaridade = $_POST['escolaridade'];
		$rg = $_POST['rg'];
		$cpf = $_POST['cpf'];
		$endereco = $_POST['endereco'];
		$numero = $_POST['numero'];
		$bairro = $_POST['bairro'];
		$cidade = $_POST['cidade'];
		$cep = $_POST['cep'];
		$funcao = $_POST['funcao'];
		$setor = $_POST['setor'];
		$tipo = $_POST['tipo'];
		$data1 = $_POST['data1'];
		$data2 = $_POST['data2'];
		$telefone = $_POST['telefone'];
		$celular = $_POST['celular'];
		$wattsap = $_POST['wattsap'];
		$email = $_POST['email'];
		$limite = $_POST['limite'];
?>